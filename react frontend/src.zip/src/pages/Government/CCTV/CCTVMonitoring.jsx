import {
  ArrowLeft,
  Camera,
  Circle,
  Maximize2,
  MapPin,
  RefreshCw,
  Search,
  ShieldCheck,
  Video,
  Wifi,
} from "lucide-react";

import { useNavigate } from "react-router-dom";
import "./CCTVMonitoring.css";

const cameraFeeds = [
  {
    id: "CCTV-001",
    project: "Project Monitoring Unit — Delhi",
    location: "New Delhi",
    status: "LIVE",
    lastUpdate: "Live",
  },
  {
    id: "CCTV-002",
    project: "Institution Monitoring Centre",
    location: "Haryana",
    status: "LIVE",
    lastUpdate: "Live",
  },
  {
    id: "CCTV-003",
    project: "Scheme Implementation Centre",
    location: "Uttar Pradesh",
    status: "LIVE",
    lastUpdate: "Live",
  },
  {
    id: "CCTV-004",
    project: "District Monitoring Centre",
    location: "Rajasthan",
    status: "OFFLINE",
    lastUpdate: "8 min ago",
  },
];

function CCTVMonitoring() {
  const navigate = useNavigate();

  return (
    <div className="cctv-page">

      {/* HEADER */}

      <header className="cctv-header">

        <div className="cctv-header-left">

          <button
            className="cctv-back-button"
            onClick={() => navigate("/government/dashboard")}
            aria-label="Back to dashboard"
          >
            <ArrowLeft size={18} />
          </button>

          <div>
            <div className="cctv-breadcrumb">
              GOVERNMENT COMMAND CENTRE
            </div>

            <h1>Live CCTV Monitoring</h1>

            <p>
              Surveillance visibility across monitored projects and institutions
            </p>
          </div>

        </div>

        <div className="cctv-header-right">

          <div className="cctv-system-status">
            <span></span>
            SURVEILLANCE SYSTEM ONLINE
          </div>

          <button className="cctv-refresh-button">
            <RefreshCw size={16} />
            Refresh
          </button>

        </div>

      </header>


      {/* MAIN CONTENT */}

      <main className="cctv-content">

        {/* SUMMARY */}

        <section className="cctv-summary">

          <div className="cctv-summary-card">

            <div className="summary-icon">
              <Video size={20} />
            </div>

            <div>
              <span>CONNECTED FEEDS</span>
              <strong>186</strong>
              <small>Active surveillance connections</small>
            </div>

          </div>


          <div className="cctv-summary-card">

            <div className="summary-icon live">
              <Wifi size={20} />
            </div>

            <div>
              <span>LIVE FEEDS</span>
              <strong>182</strong>
              <small>Currently transmitting</small>
            </div>

          </div>


          <div className="cctv-summary-card">

            <div className="summary-icon warning">
              <Circle size={20} />
            </div>

            <div>
              <span>OFFLINE FEEDS</span>
              <strong>04</strong>
              <small>Require connectivity review</small>
            </div>

          </div>


          <div className="cctv-summary-card">

            <div className="summary-icon">
              <ShieldCheck size={20} />
            </div>

            <div>
              <span>SURVEILLANCE STATUS</span>
              <strong>98%</strong>
              <small>Network availability</small>
            </div>

          </div>

        </section>


        {/* TOOLBAR */}

        <section className="cctv-toolbar">

          <div className="cctv-toolbar-title">
            <span>MONITORED LOCATIONS</span>
            <h2>Surveillance Feeds</h2>
          </div>

          <div className="cctv-toolbar-actions">

            <div className="cctv-search">
              <Search size={16} />

              <input
                type="text"
                placeholder="Search project or location..."
              />
            </div>

            <select className="cctv-filter">
              <option>All Status</option>
              <option>Live</option>
              <option>Offline</option>
            </select>

          </div>

        </section>


        {/* CAMERA GRID */}

        <section className="cctv-grid">

          {cameraFeeds.map((camera) => (

            <article
              className={`camera-card ${
                camera.status === "OFFLINE" ? "camera-offline" : ""
              }`}
              key={camera.id}
            >

              {/* CAMERA VIEW */}

              <div className="camera-view">

                <div className="camera-top">

                  <span className="camera-id">
                    {camera.id}
                  </span>

                  <span
                    className={`camera-status ${
                      camera.status === "LIVE"
                        ? "status-live"
                        : "status-offline"
                    }`}
                  >
                    <span></span>
                    {camera.status}
                  </span>

                </div>


                {camera.status === "LIVE" ? (

                  <div className="live-camera-placeholder">

                    <Camera size={36} />

                    <strong>LIVE CCTV FEED</strong>

                    <span>
                      Secure surveillance stream
                    </span>

                    <div className="stream-indicator">
                      <Circle size={8} fill="currentColor" />
                      STREAM ACTIVE
                    </div>

                  </div>

                ) : (

                  <div className="offline-camera">

                    <Camera size={34} />

                    <strong>Camera Offline</strong>

                    <span>
                      Last connection: {camera.lastUpdate}
                    </span>

                  </div>

                )}


                <button
                  className="fullscreen-button"
                  title="Open surveillance view"
                >
                  <Maximize2 size={16} />
                </button>

              </div>


              {/* CAMERA INFORMATION */}

              <div className="camera-information">

                <div>

                  <span className="camera-location-label">
                    PROJECT / INSTITUTION
                  </span>

                  <h3>{camera.project}</h3>

                </div>


                <div className="camera-location">

                  <MapPin size={14} />

                  <span>{camera.location}</span>

                </div>


                <div className="camera-footer">

                  <span>
                    Feed ID: {camera.id}
                  </span>

                  <span>
                    {camera.status === "LIVE"
                      ? "Receiving data"
                      : "Connection unavailable"}
                  </span>

                </div>

              </div>

            </article>

          ))}

        </section>


        {/* INFORMATION PANEL */}

        <section className="cctv-information">

          <div className="information-icon">
            <ShieldCheck size={19} />
          </div>

          <div>

            <strong>Secure Surveillance Infrastructure</strong>

            <p>
              CCTV feeds displayed here represent surveillance connections
              from monitored projects and institutions. Government officials
              can use this interface to review real-time availability and
              identify connectivity issues requiring attention.
            </p>

          </div>

        </section>

      </main>

    </div>
  );
}

export default CCTVMonitoring;