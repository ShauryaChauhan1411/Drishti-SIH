import {
  Activity,
  ArrowLeft,
  Bell,
  Camera,
  ClipboardCheck,
  Map,
} from "lucide-react";

import { useNavigate } from "react-router-dom";
import "./GovernmentDashboard.css";

function GovernmentDashboard() {
  return (
    <div className="gov-dashboard">

      {/* MAIN DASHBOARD CONTENT */}

      <main className="gov-main">

        <section className="dashboard-content">

          {/* WELCOME SECTION */}

          <div className="welcome-section">
            <div className="welcome-left">

    <button
      className="dashboard-back-button"
      onClick={() => navigate("/")}
      aria-label="Back"
    >
      <ArrowLeft size={18} />
    </button>
            <div>
              <span className="dashboard-tag">
                REAL-TIME MONITORING
              </span>

              <h2>
                National Monitoring Overview
              </h2>

              <p>
                Centralised visibility of projects, inspections,
                surveillance and compliance activities.
              </p>
            </div>
          </div>
            <div className="date-card">
              <span>MONITORING STATUS</span>
              <strong>LIVE</strong>
            </div>

          </div>


          {/* STATISTICS */}

          <div className="stats-grid">

            <div className="stat-card">

              <div className="stat-icon">
                <Map size={20} />
              </div>

              <div>
                <span>Total Projects</span>
                <strong>248</strong>
                <small>
                  Across monitored locations
                </small>
              </div>

            </div>


            <div className="stat-card">

              <div className="stat-icon">
                <ClipboardCheck size={20} />
              </div>

              <div>
                <span>Active Inspections</span>
                <strong>32</strong>
                <small>
                  Currently assigned
                </small>
              </div>

            </div>


            <div className="stat-card">

              <div className="stat-icon">
                <Camera size={20} />
              </div>

              <div>
                <span>Live CCTV</span>
                <strong>186</strong>
                <small>
                  Connected feeds
                </small>
              </div>

            </div>


            <div className="stat-card">

              <div className="stat-icon">
                <Activity size={20} />
              </div>

              <div>
                <span>Monitoring Alerts</span>
                <strong>07</strong>
                <small>
                  Require attention
                </small>
              </div>

            </div>

          </div>


          {/* MAIN MONITORING AREA */}

          <div className="monitor-grid">

            {/* MAP CARD */}

            <div className="monitor-card map-card">

              <div className="card-heading">

                <div>
                  <span>
                    GEOGRAPHIC MONITORING
                  </span>

                  <h3>
                    Project Distribution
                  </h3>
                </div>

                <Map size={20} />

              </div>


              <div className="map-placeholder">

                <div className="map-center">

                  <Map size={35} />

                  <strong>
                    Interactive Map
                  </strong>

                  <span>
                    Project and inspection locations
                  </span>

                </div>


                <div className="map-pin pin-one"></div>

                <div className="map-pin pin-two"></div>

                <div className="map-pin pin-three"></div>

                <div className="map-pin pin-four"></div>

              </div>

            </div>


            {/* ALERT CARD */}

            <div className="monitor-card alert-card">

              <div className="card-heading">

                <div>

                  <span>
                    ATTENTION REQUIRED
                  </span>

                  <h3>
                    Monitoring Alerts
                  </h3>

                </div>

                <Bell size={20} />

              </div>


              <div className="alert-list">

                <div className="alert-item">

                  <div className="alert-dot"></div>

                  <div>
                    <strong>
                      Inspection pending
                    </strong>

                    <span>
                      3 inspections require verification
                    </span>
                  </div>

                </div>


                <div className="alert-item">

                  <div className="alert-dot"></div>

                  <div>
                    <strong>
                      CCTV connection issue
                    </strong>

                    <span>
                      2 project feeds unavailable
                    </span>
                  </div>

                </div>


                <div className="alert-item">

                  <div className="alert-dot"></div>

                  <div>
                    <strong>
                      Attendance anomaly
                    </strong>

                    <span>
                      Detected by monitoring analytics
                    </span>
                  </div>

                </div>

              </div>

            </div>

          </div>

        </section>

      </main>

    </div>
  );
}

export default GovernmentDashboard;